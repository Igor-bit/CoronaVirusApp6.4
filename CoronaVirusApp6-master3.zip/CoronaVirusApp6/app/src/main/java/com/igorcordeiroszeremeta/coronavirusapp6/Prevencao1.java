package com.igorcordeiroszeremeta.coronavirusapp6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Prevencao1 extends AppCompatActivity {
    private Button prevencao2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prevencao1);

        prevencao2 = findViewById(R.id.botaoPrevencao2);
        prevencao2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Prevencao2.class);
                startActivity(intent);
            }
        });
    }
}